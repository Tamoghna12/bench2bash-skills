# bench2bash-skills

Two Claude skills for bioinformatics — one for learning, one for reference. Built for [bench2bash](https://tamoghna12.github.io/bench2bash.github.io/) by Tamoghna Das.

---

## Skills

### 🧬 `bioinformatics-tutor`
A Socratic teaching skill that helps anyone — wet lab biologist, CS person, or early PhD student — develop genuine biological intuition for bioinformatics problems.

**What it does:**
- Detects your background and adapts its teaching style
- Explains *why* before *how* — biology first, tools second
- Uses the Socratic method: asks questions that help you reason through problems yourself
- Teaches the "biological eye": framing questions biologically before touching a tool, and validating results biologically after
- Covers: RNA-seq, genome assembly, variant calling, ChIP-seq, metagenomics, bacterial pangenomics, metabolic modelling

**Trigger phrases:** "I'm new to bioinformatics", "what does this result mean?", "where do I start?", "I don't understand why", "does my output make sense?"

---

### 📚 `bioinformatics-fundamentals`
A precise technical reference skill for working bioinformaticians. Covers SAM/BAM format internals, filtering patterns, file format specs, assembly QC metrics, and common debugging patterns.

**What it does:**
- SAM flags, MAPQ, CIGAR strings decoded accurately
- Correct filtering order for paired-end / Hi-C data (the pair-breaking trap)
- PacBio HiFi vs Hi-C vs Illumina — technology-specific guidance
- AGP format, coordinate systems (0-based vs 1-based), BED/FASTQ/FASTA specs
- Assembly QC: N50, BUSCO, Merqury, GenomeScope
- GenomeArk data access patterns
- Bacterial pangenomics (Panaroo, Roary, PPanGGOLiN)

**Trigger phrases:** "what flag do I use", "why is my output empty", "MAPQ threshold", "samtools view", "Hi-C filtering", "AGP format"

---

## Install in Claude Cowork or Claude Code

### Option 1 — Install from `.skill` file (easiest)

1. Download the `.skill` file from the [`releases/`](releases/) folder
2. In Claude Cowork: drag the `.skill` file into the Skills panel, or double-click it
3. In Claude Code: run `claude skill install path/to/bioinformatics-tutor.skill`

### Option 2 — Install from source

Clone this repo and point Claude Code at the skill directory:

```bash
git clone https://github.com/tamoghna12/bench2bash-skills
cd bench2bash-skills
claude skill install bioinformatics-tutor/
claude skill install bioinformatics-fundamentals/
```

---

## Use with other AI coding agents

The skills are plain Markdown — any agent that can read files can use them.

**Copy the SKILL.md into your system prompt or context:**
```bash
cat bioinformatics-tutor/SKILL.md
cat bioinformatics-fundamentals/SKILL.md
```

**Or reference the raw GitHub URLs directly in your agent's instructions:**
```
https://raw.githubusercontent.com/tamoghna12/bench2bash-skills/main/bioinformatics-tutor/SKILL.md
https://raw.githubusercontent.com/tamoghna12/bench2bash-skills/main/bioinformatics-fundamentals/SKILL.md
```

The supporting files in `references/` provide deeper detail — load them as needed.

---

## Repo structure

```
bench2bash-skills/
├── bioinformatics-tutor/
│   ├── SKILL.md                        # Main skill instructions
│   └── references/
│       ├── concepts.md                 # Biological story behind each domain
│       └── learning-paths.md          # Learning progressions by background
│
├── bioinformatics-fundamentals/
│   ├── SKILL.md                        # Main skill instructions
│   └── references/
│       ├── reference.md               # Full SAM/BAM spec, AGP format, tool reference
│       ├── common-issues.md           # Troubleshooting guide
│       ├── genomeark-data-access.md   # GenomeArk S3 access patterns
│       └── genomic-analysis-patterns.md  # Karyotype, telomere, NCBI patterns
│
└── releases/
    ├── bioinformatics-tutor.skill      # Packaged for one-click install
    └── bioinformatics-fundamentals.skill
```

---

## About bench2bash

[bench2bash](https://tamoghna12.github.io/bench2bash.github.io/) is a newsletter and resource hub for biologists learning computational tools — practical terminal + AI skills for life scientists, every Tuesday.

By [Tamoghna Das](https://www.linkedin.com/in/tamoghna-das/) · PhD Researcher, Loughborough University
