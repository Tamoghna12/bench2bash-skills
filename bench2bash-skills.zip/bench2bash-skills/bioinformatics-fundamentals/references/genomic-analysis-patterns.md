# Genomic Analysis Patterns

> **Stub file.** Fill in with domain-specific analysis patterns.

---

## Table of Contents

1. [Karyotype Data Curation](#karyotype-data-curation)
2. [Haploid vs Diploid Chromosome Counts](#haploid-vs-diploid-chromosome-counts)
3. [Phylogenetic Tree Species Mapping](#phylogenetic-tree-species-mapping)
4. [BED and Telomere Analysis](#bed-and-telomere-analysis)
5. [NCBI Data Integration](#ncbi-data-integration)

---

## Karyotype Data Curation

> **TODO:** Add guidance on sources for chromosome count data (NCBI Taxonomy,
> Animal Genome Size Database, primary literature), how to curate conflicting
> counts, and how to handle polymorphic karyotypes.

> **TODO:** Add the difference between 2n (diploid), n (haploid), and
> chromosome arm number (NF).

---

## Haploid vs Diploid Chromosome Counts

> **TODO:** Add clear definition: 2n = diploid chromosome number (what you see
> in a karyogram); n = haploid number (gametes); genome assemblies target
> haploid representation.

> **TODO:** Add common confusion cases: sex chromosomes (XY, ZW, X0 systems),
> B chromosomes, Robertsonian fusions changing 2n without changing gene content.

> **TODO:** Add how to interpret VGP assembly scaffold counts relative to
> expected chromosome number.

---

## Phylogenetic Tree Species Mapping

> **TODO:** Add strategies for mapping species names between tree tip labels
> and assembly metadata:
> - Genus-species canonical form
> - Synonyms (NCBI Taxonomy `syn:` records)
> - Common-name to scientific-name resolution
> - Handling subspecies in tree vs assembly labels

> **TODO:** Add tools: NCBI Taxonomy API, Open Tree of Life API.

---

## BED and Telomere Analysis

> **TODO:** Add the canonical vertebrate telomere repeat: TTAGGG/CCCTAA.
> Add how to identify telomeric windows using `tidk` or a sliding-window k-mer
> count approach.

> **TODO:** Add interpretation: what fraction of chromosomal ends should be
> telomeric in a chromosome-level assembly, and what counts as a "telomere-to-
> telomere" (T2T) assembly.

> **TODO:** Add BED file patterns for:
> - Extracting telomeric windows
> - Intersecting telomere windows with AGP component boundaries
> - Measuring assembly completeness at chromosome ends

---

## NCBI Data Integration

> **TODO:** Add NCBI Entrez API patterns for fetching:
> - Assembly metadata (assembly accession → scaffold N50, chromosome count)
> - Taxonomy records (species name → taxid, lineage)
> - Genome annotations (RefSeq vs GenBank accession conventions)

> **TODO:** Add `datasets` CLI tool (NCBI Datasets) usage for bulk downloads.

> **TODO:** Add rate-limiting guidance for Entrez (max 3 req/s unauthenticated,
> 10 req/s with API key).
