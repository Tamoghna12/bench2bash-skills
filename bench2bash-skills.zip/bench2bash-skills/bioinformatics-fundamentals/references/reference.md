# Bioinformatics Fundamentals — Detailed Reference

> **Stub file.** This file is a structured placeholder. Fill in each section
> with the detailed reference material described below.

---

## Table of Contents

1. [SAM/BAM Complete Reference](#sambam-complete-reference)
   - Mandatory fields
   - Optional tags (NM, MD, AS, XS, SA, HP, …)
   - Complete CIGAR operation semantics
   - Full flag table (all 12 bits)
2. [AGP Format Specification](#agp-format-specification)
   - Column definitions
   - Component types (W, N, U, …)
   - Gap types and linkage evidence
   - Coordinate validation rules
   - Unloc scaffold conventions
3. [FASTQ Encoding](#fastq-encoding)
   - Phred+33 (Sanger/Illumina 1.8+) encoding table
   - Phred+64 (legacy Illumina) encoding
   - Quality score interpretation
4. [Tool Command Reference](#tool-command-reference)
   - samtools view — all flags and examples
   - samtools fastx — all flags and examples
   - bamtools filter — all filter keys and examples
   - minimap2 — presets and key options
   - BWA-MEM2 — key options
5. [Sequencing Technology Specifications](#sequencing-technology-specifications)
   - PacBio HiFi: error profiles, read-length distributions, CCS details
   - Hi-C: library prep, ligation junction sequences, chimeric reads
   - Illumina: error profiles, adapter sequences, quality score profiles
6. [Assembly Quality Metrics](#assembly-quality-metrics)
   - N50 / L50 / NG50 calculation details
   - BUSCO interpretation (lineage selection, completeness thresholds)
   - QV (quality value) / Merqury scores
   - GenomeScope output interpretation
7. [Coverage Calculations](#coverage-calculations)
   - Formula: coverage = (read_count × read_length) / genome_size
   - Calculating required sequencing depth
   - Interpreting samtools coverage output
8. [Coordinate Systems — Extended](#coordinate-systems--extended)
   - Conversion examples
   - Common pitfalls (off-by-one errors)
   - Tool-specific coordinate conventions

---

## SAM/BAM Complete Reference

> **TODO:** Add mandatory field table (QNAME, FLAG, RNAME, POS, MAPQ, CIGAR,
> RNEXT, PNEXT, TLEN, SEQ, QUAL) with types and constraints.

> **TODO:** Add optional tag table (NM, MD, AS, XS, SA, HP, RG, CB, UB, etc.)
> with types and descriptions.

> **TODO:** Add complete CIGAR operation table (M, I, D, N, S, H, P, =, X)
> with consuming-read and consuming-reference flags.

---

## AGP Format Specification

> **TODO:** Add full column definitions for both sequence lines (columns 1–9
> for component type W) and gap lines (columns 1–9 for component types N/U).

> **TODO:** Add gap-type enumeration (scaffold, contig, centromere,
> short_arm, heterochromatin, telomere, repeat, contamination, unknown).

> **TODO:** Add linkage evidence types (na, paired-ends, align_genus,
> align_xgenus, align_trnscpt, within_clone, clone_contig, map,
> proximity_ligation, strobe, unspecified).

> **TODO:** Add coordinate validation rules and worked example.

> **TODO:** Add unloc scaffold naming conventions and processing patterns.

---

## FASTQ Encoding

> **TODO:** Add Phred+33 ASCII encoding table (! = Q0, I = Q40, ~= Q93).

> **TODO:** Add quality score to error probability conversion table.

---

## Tool Command Reference

> **TODO:** Add samtools view full flag table and worked examples.

> **TODO:** Add samtools fastx full flag table and worked examples.

> **TODO:** Add bamtools filter JSON filter syntax and all filter keys.

> **TODO:** Add minimap2 preset table (map-hifi, map-pb, sr, map-ont, asm5,
> asm10, asm20, splice) with recommended use cases.

> **TODO:** Add BWA-MEM2 key options and paired-end invocation patterns.

---

## Sequencing Technology Specifications

> **TODO:** Expand PacBio HiFi section with CCS pass count, accuracy curve,
> subread vs CCS BAM differences, kinetics tags.

> **TODO:** Expand Hi-C section with restriction enzyme sites (DpnII, MboI,
> HindIII, Arima), expected ligation junction sequences, dangling-end filtering,
> self-circle removal.

> **TODO:** Expand Illumina section with adapter sequences (TruSeq, Nextera),
> typical quality score curves, tile-based quality patterns.

---

## Assembly Quality Metrics

> **TODO:** Add BUSCO lineage selection guidance for bacteria vs eukaryotes.
> Add completeness percentage thresholds (> 95 % for chromosome-level).

> **TODO:** Add QV score formula (QV = -10 × log₁₀(error_rate)) and
> relationship to k-mer completeness in Merqury.

> **TODO:** Add GenomeScope2 output interpretation: genome size estimate,
> heterozygosity, ploidy inference.

---

## Coverage Calculations

> **TODO:** Add worked examples for HiFi (assume 10 Gb genome, 40× depth →
> required data volume) and Hi-C scaffolding depth estimation.

---

## Coordinate Systems — Extended

> **TODO:** Add conversion table with tool-specific notes (IGV, UCSC, Ensembl
> all use 1-based; BEDTools uses 0-based; common off-by-one traps).
