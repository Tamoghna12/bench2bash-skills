# GenomeArk Data Access

> **Stub file.** Fill in with detailed GenomeArk AWS S3 data access patterns.

---

## Table of Contents

1. [Overview](#overview)
2. [S3 Directory Structure](#s3-directory-structure)
3. [Directory Structure Evolution](#directory-structure-evolution)
4. [QC Data Locations](#qc-data-locations)
5. [Fetching Strategies](#fetching-strategies)
6. [Path Normalisation](#path-normalisation)
7. [Assembly Date Extraction](#assembly-date-extraction)

---

## Overview

GenomeArk is the Vertebrate Genomes Project (VGP) data repository hosted on
AWS S3 at `s3://genomeark`. It is publicly readable without credentials using
`--no-sign-request`.

> **TODO:** Add bucket access note, cost considerations (egress), and AWS CLI
> setup.

---

## S3 Directory Structure

> **TODO:** Add canonical directory tree showing species → assembly →
> genomic_data, assembly_curated, assembly_pipeline folders.

```
s3://genomeark/species/
  <CommonName>_<GenusSpecies>/
    <ToLID>/
      genomic_data/
        pacbio_hifi/
        hic/
        illumina/
      assembly_curated/
        <ToLID>.<version>/
          <ToLID>.<version>.pri.cur.20*.fasta.gz
          ...
      assembly_pipeline/
        ...
```

> **TODO:** Expand with actual example paths and naming conventions.

---

## Directory Structure Evolution

> **TODO:** Document how the directory layout has changed across VGP phases
> (v1, v1.6, v2, v3) so old paths can be parsed correctly.

---

## QC Data Locations

> **TODO:** Add exact S3 paths for:
> - GenomeScope2 output (model.txt, summary.txt, linear_plot.png)
> - BUSCO results (short_summary.*.txt)
> - Merqury output (*.qv, *.completeness.stats)
> - assembly_stats output

---

## Fetching Strategies

> **TODO:** Add `aws s3 ls` and `aws s3 cp` patterns with `--no-sign-request`.
> Add `aws s3 sync` for bulk downloads.

```bash
# List assemblies for a species
aws s3 ls --no-sign-request s3://genomeark/species/Lynx_canadensis/mLynCan4/

# Download a specific file
aws s3 cp --no-sign-request \
  s3://genomeark/species/Lynx_canadensis/mLynCan4/assembly_curated/... \
  ./local_path/
```

---

## Path Normalisation

> **TODO:** Document common path inconsistencies (trailing slashes, species name
> capitalisation, ToLID prefix matching) and normalisation strategies.

---

## Assembly Date Extraction

> **TODO:** Document how to extract the assembly curation date from filenames
> (`.pri.cur.YYYYMMDD.`) and from S3 metadata, and why this matters for
> reproducibility.
