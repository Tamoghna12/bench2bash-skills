# Bioinformatics Fundamentals — Common Issues & Troubleshooting

> **Stub file.** This file is a structured placeholder. Fill in each section
> with the detailed troubleshooting material described below.

---

## Table of Contents

1. [Empty Output After Region Filtering](#empty-output-after-region-filtering)
2. [Paired-End Read Count Mismatches](#paired-end-read-count-mismatches)
3. [Low Mapping Rate](#low-mapping-rate)
4. [Proper Pairs Lost After Mapping](#proper-pairs-lost-after-mapping)
5. [Hi-C Specific Issues](#hi-c-specific-issues)
6. [HiFi Specific Issues](#hifi-specific-issues)
7. [AGP Processing Errors](#agp-processing-errors)
8. [Format Conversion Issues](#format-conversion-issues)
9. [Diagnostic Commands Reference](#diagnostic-commands-reference)

---

## Empty Output After Region Filtering

**Symptom:** `samtools view -L regions.bed | bamtools filter -isProperPair true`
produces zero reads.

**Root cause:** Region filter checks each read in isolation. When mate pairs map
to different chromosomes/scaffolds (common in Hi-C), the mate outside the region
is filtered out first. With the mate gone, the surviving read no longer has a
proper pair, and the pair filter removes it too.

**Fix:** Always apply the proper-pair filter *before* the region filter:

```bash
samtools view -b -f 2 -L regions.bed input.bam > output.bam
```

> **TODO:** Add more worked examples with different tool combinations.

> **TODO:** Add diagnostic: how to distinguish "empty because of pair-breaking"
> vs "empty because there are genuinely no reads in this region".

---

## Paired-End Read Count Mismatches

**Symptom:** `wc -l R1.fastq` ≠ `wc -l R2.fastq` after `samtools fastx`.

**Root cause:** Filtering removed one mate of a pair without removing the other.

**Fix:** Require proper pairs during FASTQ extraction:

```bash
samtools fastx -1 R1.fq.gz -2 R2.fq.gz --i1-flags 2 input.bam
```

> **TODO:** Add repair strategies for already-mismatched FASTQ files
> (`repair.sh` from BBTools, `pairfq`, etc.).

---

## Low Mapping Rate

**Symptom:** < 70 % of reads map; low overall mapping rate in `samtools flagstat`.

> **TODO:** Add decision tree: Is it Hi-C (expect lower, chimeric reads normal)?
> Reference mismatch? Wrong mapper preset? Contamination?

> **TODO:** Add commands to diagnose: check unmapped read sequences,
> BLAST a sample, check adapter content with FastQC.

---

## Proper Pairs Lost After Mapping

> **TODO:** Add diagnosis workflow:
> 1. `samtools stats input.bam | grep "insert size"`
> 2. `samtools flagstat input.bam`
> 3. Check orientation flags — are R1/R2 swapped?
> 4. Check reference chromosome naming (chr1 vs 1).

---

## Hi-C Specific Issues

> **TODO:** Add: dangling-end artefacts, self-ligation artefacts, expected
> proportion of trans vs cis reads, Hi-C-specific QC tools (HiCExplorer
> hicQuickQC, Juicer pipeline warnings).

---

## HiFi Specific Issues

> **TODO:** Add: CCS vs subread BAM confusion, kinetics tag presence/absence,
> why MAPQ = 0 is common for HiFi repeats, adapter trimming (pbadapterfinder),
> checking zmw coverage depth.

---

## AGP Processing Errors

> **TODO:** Add: coordinate arithmetic errors (off-by-one in 1-based closed
> intervals), component length mismatch, invalid gap types for given AGP
> version, unloc scaffold processing order, cumulative coordinate re-calculation
> after insertions/deletions.

---

## Format Conversion Issues

> **TODO:** Add: BAM to FASTQ pitfalls (sort order matters — sort by name
> before converting paired-end), FASTQ to FASTA quality stripping,
> coordinate system conversion errors (BED ↔ SAM).

---

## Diagnostic Commands Reference

```bash
# Check overall mapping statistics
samtools flagstat input.bam

# Detailed statistics including insert size distribution
samtools stats input.bam | grep -E "^SN|^IS" | head -60

# Check flag distribution
samtools view -c -f 2 input.bam     # properly paired
samtools view -c -F 4 input.bam     # mapped
samtools view -c -f 4 input.bam     # unmapped

# Check if BAM is sorted (name sort needed for FASTQ conversion)
samtools view -H input.bam | grep "^@HD"

# Quick region check — how many reads overlap a region?
samtools view -c input.bam chr1:1000000-2000000
```

> **TODO:** Add more diagnostic commands with example outputs and
> interpretation guidance.
